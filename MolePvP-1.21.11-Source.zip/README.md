# Mole PvP Helper — Minecraft Java 1.21.11

A fresh Fabric client-mod source project. It is an experimental starter, not a verified exact recreation of the video.

## Current behavior
- Press F6 to toggle the helper.
- While enabled, using a cobweb item or attacking a cobweb starts a short targeting window.
- During that window, it aims toward the nearest living entity within 4.5 blocks.
- It attempts a normal attack only when the target is under ordinary reach, the attack cooldown is ready, and the crosshair is on that entity.

## Important limitations
- It does **not** automatically place cobwebs, break shields, perform a complete combo, or guarantee identical timing to the video.
- Test only in a world/server where automation is allowed.
- Build/API versions in `gradle.properties` may need updating if Fabric's Maven metadata changes. The GitHub Actions workflow builds the project and uploads the resulting JAR if successful.

## Build
1. Upload the contents of this folder to a new GitHub repository (not the ZIP file inside another ZIP).
2. Open **Actions** and run **Build MolePvP source** (or push to `main`).
3. Open the completed workflow run and download the `molepvp-build` artifact.
4. Extract the artifact ZIP and copy the `.jar` into `.minecraft/mods`.
5. Install Fabric Loader and Fabric API for Minecraft 1.21.11.

Java 21 is required.
