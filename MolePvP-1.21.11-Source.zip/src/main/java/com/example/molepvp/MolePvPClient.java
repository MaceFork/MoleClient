package com.example.molepvp;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.block.Blocks;
import org.lwjgl.glfw.GLFW;

/**
 * Experimental starter implementation for Minecraft Java 1.21.11.
 *
 * F6 toggles the helper. Using a cobweb item or attacking a cobweb starts a
 * short targeting window. During that window it aims at the nearest living
 * entity within 4.5 blocks and performs a normal client attack when in range.
 *
 * This is a starter project, not a verified recreation of the uploaded video.
 */
public final class MolePvPClient implements ClientModInitializer {
    private static boolean enabled = false;
    private static boolean previousF6 = false;
    private static boolean previousUse = false;
    private static boolean previousAttack = false;
    private static int activeTicks = 0;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(MolePvPClient::tick);
    }

    private static void tick(MinecraftClient client) {
        if (client.player == null || client.world == null || client.getWindow() == null) {
            return;
        }

        long handle = client.getWindow().getHandle();
        boolean f6 = GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_F6) == GLFW.GLFW_PRESS;
        if (f6 && !previousF6) {
            enabled = !enabled;
            client.player.sendMessage(
                net.minecraft.text.Text.literal("Mole PvP Helper: " + (enabled ? "ON" : "OFF")),
                true
            );
            activeTicks = 0;
        }
        previousF6 = f6;

        boolean usePressed = client.options.useKey.isPressed();
        boolean attackPressed = client.options.attackKey.isPressed();

        if (enabled) {
            boolean holdingCobweb = client.player.getMainHandStack().isOf(Items.COBWEB)
                || client.player.getOffHandStack().isOf(Items.COBWEB);

            boolean usingCobweb = holdingCobweb && usePressed && !previousUse;
            boolean attackingCobweb = attackPressed && !previousAttack
                && client.crosshairTarget instanceof BlockHitResult blockHit
                && client.world.getBlockState(blockHit.getBlockPos()).isOf(Blocks.COBWEB);

            if (usingCobweb || attackingCobweb) {
                activeTicks = 30;
            }

            if (activeTicks > 0) {
                LivingEntity target = findNearestTarget(client);
                if (target != null) {
                    aimAt(client, target);

                    // Keep the attack to ordinary Minecraft reach and cooldown.
                    if (client.player.squaredDistanceTo(target) <= 4.5 * 4.5
                        && client.player.getAttackCooldownProgress(0.0f) >= 0.9f
                        && client.crosshairTarget instanceof net.minecraft.util.hit.EntityHitResult entityHit
                        && entityHit.getEntity() == target
                        && client.interactionManager != null) {
                        client.interactionManager.attackEntity(client.player, target);
                        client.player.swingHand(Hand.MAIN_HAND);
                    }
                }
                activeTicks--;
            }
        }

        previousUse = usePressed;
        previousAttack = attackPressed;
    }

    private static LivingEntity findNearestTarget(MinecraftClient client) {
        Vec3d eye = client.player.getEyePos();
        return client.world.getEntitiesByClass(
                LivingEntity.class,
                client.player.getBoundingBox().expand(4.5),
                entity -> entity != client.player && entity.isAlive() && !entity.isSpectator()
            )
            .stream()
            .min((a, b) -> Double.compare(
                eye.squaredDistanceTo(a.getBoundingBox().getCenter()),
                eye.squaredDistanceTo(b.getBoundingBox().getCenter())
            ))
            .orElse(null);
    }

    private static void aimAt(MinecraftClient client, LivingEntity target) {
        Vec3d from = client.player.getEyePos();
        Vec3d to = target.getBoundingBox().getCenter();
        double dx = to.x - from.x;
        double dy = to.y - from.y;
        double dz = to.z - from.z;
        double horizontal = Math.sqrt(dx * dx + dz * dz);

        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, horizontal));

        client.player.setYaw(client.player.getYaw()
            + MathHelper.wrapDegrees(yaw - client.player.getYaw()));
        client.player.setPitch(MathHelper.clamp(pitch, -90.0f, 90.0f));
    }
}
